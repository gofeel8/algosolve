import Vue from "vue";
import Vuex from "vuex";
import axios from 'axios'

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    emps: []
  },
  getters: {
    emps(state) {
      return state.emps;
    }
  },
  mutations: {
    setEmps(state, payload) {
      state.emps = payload;
    }
  },
  actions: {
    getEmps(context) {
      axios.get('http://localhost:8080/ssafy/api/employee/all').then(({
        data
      }) => {
        context.commit('setEmps', data);
      })
    }
  }
});