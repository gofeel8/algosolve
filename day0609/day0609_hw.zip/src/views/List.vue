<template>
  <div>
    <h1 class="text-center">사원 목록</h1>
    <div v-if="emps.length > 0">
      <input type="text" v-model="keyword" />
      <button class="btn btn-outline-dark" @click="search">검색</button>

      <table class="table table-bordered table-condensed">
        <colgroup>
          <col :style="{ width: '20%' }" />
          <col :style="{ width: '25%' }" />
          <col :style="{ width: '25%' }" />
          <col :style="{ width: '20%' }" />
        </colgroup>

        <tr>
          <th>이름</th>
          <th>직책</th>
          <th>입사일</th>
          <th>연봉</th>
          <th>선택</th>
          <th>퇴사</th>
        </tr>
        <tr v-for="emp of emps" :key="emp.id">
          <td>
            <router-link :to="'/detail/' + emp.id">{{ emp.name }}</router-link>
          </td>
          <td>{{ emp.title }}</td>
          <td>{{ emp.start_date }}</td>
          <td>{{ emp.salary }}</td>
          <td>
            <input
              type="checkbox"
              :id="emp.id"
              :vlaue="emp.id"
              :name="emp.id"
              v-model="selectid"
            />
          </td>
          <td>
            <input
              type="button"
              :vlaue="emp.id"
              :name="emp.id"
              @click="hireemp"
            />
          </td>
        </tr>
      </table>
    </div>
    <div v-else>
      <input type="text" v-model="keyword" />
      <button class="btn btn-outline-dark" @click="search(emp.id)">검색</button>

      사원이 없습니다.
    </div>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import axios from "axios";
export default {
  data() {
    return {
      keyword: "",
      selectid: [],
    };
  },
  computed: {
    ...mapGetters(["emps"]), // 현재 List.vue에서 보여질 데이터는 vuex한테서 꺼내와야징
  },
  created() {
    this.$store.dispatch("getEmps");
  },

  methods: {
    search() {
      let stored = [];

      axios
        .get("http://localhost:8080/ssafy/api/employee/all")
        .then(({ data }) => {
          stored = data;

          if (this.keyword.length != 0) {
            this.emps = stored.filter((emp) => {
              return emp.name == this.keyword;
            });
          } else {
            this.emps = stored;
          }
        });
    },
    hireemp(event) {
      let id = event.target.name;
      // alert(id);
      axios
        .delete("http://localhost:8080/ssafy/api/employee/" + id)
        .then(({ data }) => {
          if (data == "success") {
            alert("퇴사성공" + data);
            location.reload();
          }
        });
    },
  },
};
</script>

<style></style>
