<template>
  <div>
    {{ id }}번 사원 상세정보
    <hr />

    <div>
      <!-- <router-link :to="{ name: 'boardlist' }">목록</router-link> -->
      <!-- <router-link :to="'/board/update/' + no">수정</router-link> -->
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      id: 0,
    };
  },
  created() {
    console.dir(this.$route); // 현재 호출된 해당 라우터 정보
    this.id = this.$route.params.id;
  },
};
</script>

<style></style>
