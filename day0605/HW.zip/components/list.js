export default {
    template: `  <div>     <h1 class="text-center">사원 목록</h1>
    <div v-if="list.length>0">

        <input type="text" v-model="keyword"> <button class="btn btn-outline-dark" @click="search">검색</button>

        <table class="table table-bordered table-condensed">
            <colgroup>
                <col :style="{'width' : '20%'}" />
                <col :style="{'width' : '25%'}" />
                <col :style="{'width' : '25%'}" />
                <col :style="{'width' : '20%'}" />
            </colgroup>
            <tr>
                <th>이름</th>
                <th>직책</th>
                <th>입사일</th>
                <th>연봉</th>
            </tr>
            <tr v-for="emp of list">
                <td>{{emp.name}}</td>
                <td>{{emp.title}}</td>
                <td>{{emp.start_date}}</td>
                <td>{{emp.salary}}</td>
            </tr>
        </table>



    </div>
    <div v-else>
    <input type="text" v-model="keyword"> <button class="btn btn-outline-dark" @click="search">검색</button>

        사원이 없습니다.
    </div>
    </div> 
    `,
    data() {
        return {
            keyword: "",
            list: []
        }
    },
    created() {
        axios.get("http://localhost:8080/ssafy/api/employee/all")
            .then(({
                data
            }) => {
                console.dir(data);
                this.list = data;
            });

    },

    methods: {
        search() {
            let stored = []

            axios.get("http://localhost:8080/ssafy/api/employee/all")
                .then(({
                    data
                }) => {
                    stored = data;

                    if (this.keyword.length != 0) {

                        this.list = stored.filter((emp) => {
                            return emp.name == this.keyword;
                        })
                    } else {
                        this.list = stored;
                    }

                });




        }
    }

}