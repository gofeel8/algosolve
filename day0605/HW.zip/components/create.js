export default {
    template: `
      <div>

        <h1 class="text-center">사원 등록</h1>
        <div class="form-group">
            <label for="id">ID</label>
            <input type="text" class="form-control" id="id" name="id" ref="id" placeholder="id" v-model="id">
        </div>

        <div class="form-group">
            <label for="name">이름</label>
            <input type="text" class="form-control" id="name" name="name" ref="name" placeholder="name" v-model="name">
        </div>

        <div class="form-group">
            <label for="mailid">이메일</label>
            <input type="text" class="form-control" id="mailid" name="mailid" ref="mailid" placeholder="mailid"
                v-model="mailid">
        </div>

        <div class="form-group">
            <label for="start_date">고용일</label>
            <input type="date" class=" form-control" id="start_date" name="start_date" ref="start_date" placeholder="start_date"
                v-model="start_date">
        </div>

        <div class="form-group">
            <label for="manager_id">관리자</label>
            <input type="number" class="form-control" id="manager_id" name="manager_id" ref="manager_id" placeholder="manager_id"
                v-model="manager_id">
        </div>

        <div class="form-group">
            <label for="title">직책</label>
            <input type="text" class="form-control" id="title" name="title" ref="title" placeholder=" title"
                v-model="title">
        </div>
        <div class="form-group">
            <label for="dept_id">부서</label>
            <input type="text" class="form-control" id="dept_id" name="dept_id" ref="dept_id" placeholder="dept_id" v-model="dept_id">
        </div>

        <div class="form-group">
            <label for="salary">월급</label>
            <input type="number" class="form-control" id="salary" name="salary" ref="salary" placeholder="salary"
                v-model="salary">
        </div>
        <div class="form-group">
            <label for="commission_pct">커미션</label>
            <input type="number" class="form-control" id="commission_pct" name="commission_pct" ref="commission_pct" placeholder="commission_pct"
                v-model="commission_pct">
        </div>


        <div>
            <p class="text-center"><button class="btn btn-success" @click="add">사원 등록</button></p>
            <p class="text-right"><a class="btn btn-outline-primary" href="list.html">목록으로</a></p>
        </div>



    </div>
    `,
    data() {
        return {
            id: "",
            name: "",
            mailid: "",
            start_date: "",
            manager_id: "",
            title: "",
            dept_id: "",
            salary: "",
            commission_pct: "",
            emps: []
        }
    },
    methods: {
        add() {
            //alert("눌림");
            axios.post('http://localhost:8080/ssafy/api/employee', {
                id: this.id,
                name: this.name,
                mailid: this.mailid,
                start_date: this.start_date,
                manager_id: this.manager_id,
                title: this.title,
                dept_id: this.dept_id,
                salary: this.salary,
                commission_pct: this.commission_pct
            }).then(({
                data
            }) => {
                if (data == 'success') {
                    alert('등록이 완료되었습니다.');
                } else {
                    alert('등록 과정에 문제가 발생하였습니다.')
                }
                this.$router.push('/');
            })

        }
    }

}