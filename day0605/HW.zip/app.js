// 라우트 컴포넌트
import List from './components/list.js';
import Create from './components/create.js';

// 라우터 객체 생성
const router = new VueRouter({
  routes: [{
      path: '/',
      name: 'main',
      component: List
    },
    {
      path: '/create',
      name: 'createEmp',
      component: Create
    }
  ]
});

// Vue 인스턴트 라우터 주입
const app = new Vue({
  el: '#app',
  router,
});