package com.ssafy.library;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ssafy.book.dto.Book;
import com.ssafy.book.service.BookServiceImpl;


@WebServlet("/enroll.do")
public class enroll extends HttpServlet{
	@Override
	public void init() throws ServletException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String no = request.getParameter("no");
		String title = request.getParameter("title");
		String type = request.getParameter("type");
		String date = request.getParameter("date");
		String comp = request.getParameter("comp");
		String writer = request.getParameter("writer");
		String price = request.getParameter("price");
//		System.out.println(no+title+type+date+comp+writer+price);
		
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		int cnt = 0;
		Book tmp =  new Book(Integer.parseInt(no), title, type, date, comp, writer, Integer.parseInt(price));
		BookServiceImpl service = new BookServiceImpl();
		if(service.insertBook(tmp)) {
			request.setAttribute("book", tmp);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/book/result.jsp");
			dispatcher.forward(request, response);
		}else {
			response.sendRedirect("/library/login/error.jsp");
		}
		
//		try {
//			conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3305/library?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8&useSSL=false", "ssafy", "ssafy");
//			StringBuilder insertBook = new StringBuilder();
//			insertBook.append("insert into book (no, title, type, date,comp,writer,price) \n");
//			insertBook.append("values (?, ?, ?, ?,?,?,?)");
//			pstmt = conn.prepareStatement(insertBook.toString());
//			pstmt.setInt(1, Integer.parseInt(no));
//			pstmt.setString(2, title);
//			pstmt.setString(3, type);
//			pstmt.setString(4, date);
//			pstmt.setString(5, comp);
//			pstmt.setString(6, writer);
//			pstmt.setInt(7, Integer.parseInt(price));
//			cnt=pstmt.executeUpdate();
//			System.out.println("cnt:"+cnt);
//
//		} catch (SQLException e) {
//			System.out.println("오류");
//			e.printStackTrace();
//		}finally {
//			try {
//				if(pstmt != null)
//					pstmt.close();
//				if(conn != null)
//					conn.close();
//			} catch (SQLException e) {
//				e.printStackTrace();
//			}
//		}
//		
//		if(cnt != 0) {
//			request.setAttribute("book", tmp);
//			RequestDispatcher dispatcher = request.getRequestDispatcher("/book/result.jsp");
//			dispatcher.forward(request, response);
//			
//		} else {
//			response.sendRedirect("/library/login/error.jsp");
//		}

	}

}
