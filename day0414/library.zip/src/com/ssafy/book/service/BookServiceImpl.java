package com.ssafy.book.service;

import java.sql.SQLException;

import com.ssafy.book.dao.bookDaoImpl;
import com.ssafy.book.dto.Book;

public class BookServiceImpl implements BookService {
	private bookDaoImpl dao ;

	public BookServiceImpl() {
		dao = new bookDaoImpl();
	}

	@Override
	public boolean insertBook(Book book) {
		try {
			dao.insertBook(book);
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;

	}

}
