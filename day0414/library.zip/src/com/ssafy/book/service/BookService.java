package com.ssafy.book.service;

import com.ssafy.book.dto.Book;

public interface BookService {
	public boolean insertBook(Book book);

}
