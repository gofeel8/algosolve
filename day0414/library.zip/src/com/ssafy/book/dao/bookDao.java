package com.ssafy.book.dao;

import java.sql.SQLException;

import com.ssafy.book.dto.Book;

public interface bookDao {
	public void insertBook(Book book) throws SQLException;

}
