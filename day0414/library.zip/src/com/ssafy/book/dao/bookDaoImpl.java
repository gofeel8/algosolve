package com.ssafy.book.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.ssafy.book.dto.Book;
import com.ssafy.library.util.DBUtil;

public class bookDaoImpl implements bookDao {

	@Override
	public void insertBook(Book book) throws SQLException {
		Connection conn =null;
		PreparedStatement pstmt = null;
		
		try {
			
		conn = DBUtil.getConnection();
		StringBuilder insertBook = new StringBuilder();
		insertBook.append("insert into book (no, title, type, date,comp,writer,price) \n");
		insertBook.append("values (?, ?, ?, ?,?,?,?)");
		pstmt = conn.prepareStatement(insertBook.toString());
		pstmt.setInt(1, book.getNo());
		pstmt.setString(2, book.getTitle());
		pstmt.setString(3, book.getType());
		pstmt.setString(4, book.getDate());
		pstmt.setString(5, book.getComp());
		pstmt.setString(6, book.getWriter());
		pstmt.setInt(7, book.getPrice());
		pstmt.executeUpdate();
		}finally {
			if(conn!=null)
				DBUtil.close(conn);
			if(pstmt != null)
				DBUtil.close(pstmt);
		}
	}

}
