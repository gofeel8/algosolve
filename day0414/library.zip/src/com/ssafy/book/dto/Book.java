package com.ssafy.book.dto;

public class Book {
	int no;
	String title;
	String type;
	String date;
	String comp;
	String writer;
	int price;
	public Book(int no, String title, String type, String date, String comp, String writer, int price) {
		super();
		this.no = no;
		this.title = title;
		this.type = type;
		this.date = date;
		this.comp = comp;
		this.writer = writer;
		this.price = price;
	}
	public Book() {
		super();
	}
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getComp() {
		return comp;
	}
	public void setComp(String comp) {
		this.comp = comp;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Book [no=" + no + ", title=" + title + ", type=" + type + ", date=" + date + ", comp=" + comp
				+ ", writer=" + writer + ", price=" + price + "]";
	}
	
	

}
