import Vue from "vue";
import VueRouter from "vue-router";

import List from '@/views/List.vue';
import Create from '@/views/Create.vue';
import Detail from '@/views/Detail.vue';



Vue.use(VueRouter);

const routes = [{
    path: "/",
    name: "main",
    component: List
  },
  {
    path: "/create",
    name: "createEmp",
    component: Create
  },
  {
    path: "/detail/:id",
    name: "detailEmp",
    component: Detail
  }
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes
});

export default router;