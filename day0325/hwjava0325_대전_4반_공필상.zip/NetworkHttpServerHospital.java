package hw;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class NetworkHttpServerHospital {

	public static void main(String[] args) {
		int port = 8080;
		
		Patient patient_1 = new Patient("공필상", 27, "01049230847", "Cold", "unviHospital", false);
		Patient patient_2 = new Patient("홍동", 60, "01051636123", "Fracture", "localHospital", false);
		
		List<Patient> patientList = new ArrayList<Patient>();
		patientList.add(patient_1);
		patientList.add(patient_2);
		
		StringBuilder sb = new StringBuilder();
		sb.append("<html><body><h2>환자정보</h2><table style='border: 1px solid green;'>");
	      for (Patient h : patientList) {
	    	  StringBuilder name = new StringBuilder();
	    	  for(int i=0;i<h.getName().length();i++) {
	    		  if(i==0) {
	    			  name.append(h.getName().charAt(i));
	    		  }else {
	    			  name.append("*");
	    		  }
	    	  }
	          sb.append("<tr style='border: 1px solid green;'><td>").append(name.toString()).append("</td><td>")
	                .append(String.valueOf(h.getPhone().substring(0,7)+"****")).append("</td></tr>");
	       }
	       sb.append("</table></body></html>");
		
		
		
		String html = sb.toString();
		try (ServerSocket serverSocket = new ServerSocket(port)) {

			System.out.println("started");

			while (true) {
				try (Socket socket = serverSocket.accept()) {

					BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), "UTF-8"));

					bw.write("HTTP/1.1 200 OK \r\n");
					bw.write("Content-Type: text/html;charset=utf-8\r\n");
					bw.write("Content-Length: " + html.length() + "\r\n");
					bw.write("\r\n");
					bw.write(html);
					bw.write("\r\n");
					bw.flush();

				} catch (IOException e) {
					e.printStackTrace();
				}

				System.out.println("NetworkSimple Server Ended");

			}
		} catch (IOException e1) {
			e1.printStackTrace();
		}

	}

}
