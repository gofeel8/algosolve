package medical;

import java.util.List;

import person.Patient;

public interface MedicalAction {
	void addPatient(CDC cdc,Patient p) throws NotCoronaException;  //환자 추가
	void removePatient(CDC cdc,Patient p); //환자 삭제
	void writeReport(List<Patient> pList);//전체현황

}
