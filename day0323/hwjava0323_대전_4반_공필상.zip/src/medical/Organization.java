package medical;

public class Organization {
	private String name;          //기관명
	private int employeeCount;    //직원수

	
	//생성자 추가 (기본 생성장 , 멤버변수를 매개변수로 받는 생성자를 추가하세요)
	public Organization() {
		super();
	}
	public Organization(String name, int employeeCount) {
		super();
		this.name = name;
		this.employeeCount = employeeCount;
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getEmployeeCount() {
		return employeeCount;
	}
	public void setEmployeeCount(int employeeCount) {
		this.employeeCount = employeeCount;
	}
	
	
	public void about() {
		System.out.println("Origanization : "+name);
	}
	
}



