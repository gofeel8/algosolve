package com.ssafy.board.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ssafy.board.dto.BoardDTO;

@Component
public class BoardDAOImpl implements BoardDAO {
	
	@Autowired
	SqlSession session;

	@Override
	public int insertBoard(BoardDTO board) {
		return session.insert("board-mapper.insert", board);
	}

	@Override
	public BoardDTO selectBoard(int no) {
		return session.selectOne("board-mapper.selectBoard",no);
	}

	@Override
	public List<BoardDTO> selectAllBoard() {
		return session.selectList("board-mapper.selectAll");
	}

	@Override
	public void updateBoard(BoardDTO board) {
		session.update("board-mapper.updateBoard", board);

	}

	@Override
	public void deleteBoard(int no) {
		session.delete("board-mapper.deleteBoard",no);

	}

}
