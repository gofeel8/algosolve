package com.ssafy.board.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.ssafy.board.dto.BoardDTO;
import com.ssafy.board.service.BoardService;

@Controller
public class BoardController {
	@Autowired
	BoardService service;
	
	@GetMapping("/")
	public String first() {
		return "redirect:/list";
	}
	@GetMapping("/list")
	public String list(Model model) {
		model.addAttribute("boards", service.searchAll());
		return "list";
	}
	
	@GetMapping("/enrollForm")
	public String enrollform() {
		return "enroll";
	}
	
	@PostMapping("/enroll")
	public String enroll(BoardDTO board) {
		service.createBoard(board);
		return "redirect:/list";
	}
	
	@GetMapping("/show")
	public String show(int no,Model model) {
		model.addAttribute("board", service.search(no));
		return "detail";
	}
	
	@PostMapping("/edit")
	public String edit(BoardDTO board) {
		System.out.println(board);
		service.edit(board);
		return "redirect:/list";
	}
	
	@GetMapping("/mvedit")
	public String mvedit(int no,Model model) {
		model.addAttribute("board", service.search(no));
		return "enroll";
	}
	@GetMapping("/delete")
	public String remove(int no) {
		service.remove(no);
		return  "redirect:/list";
	}

}
