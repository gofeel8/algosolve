package com.ssafy.board.dao;

import java.util.List;

import com.ssafy.board.dto.BoardDTO;

public interface BoardDAO {
	int insertBoard(BoardDTO board);
	BoardDTO selectBoard(int no);
	List<BoardDTO> selectAllBoard();
	void updateBoard(BoardDTO board);
	void deleteBoard(int no);
}
