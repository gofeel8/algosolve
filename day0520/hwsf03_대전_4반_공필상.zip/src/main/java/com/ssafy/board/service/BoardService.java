package com.ssafy.board.service;

import java.util.List;

import com.ssafy.board.dto.BoardDTO;

public interface BoardService {
	public int createBoard(BoardDTO board);
	public List<BoardDTO> searchAll();
	public BoardDTO search(int no);
	public void edit(BoardDTO board);
	public void remove(int no);
	

}
