package com.ssafy.board.dto;

public class BoardDTO {
	private int articleno;
	private String userid;
	private String title;
	private String content;
	private int hit;
	private String regtime;
	
	
	
	public BoardDTO() {
		super();
		System.out.println("기본 생성자 소환");
	}


	public BoardDTO(int articleno, String userid, String subject, String content, int hit, String regtime) {
		super();
		this.articleno = articleno;
		this.userid = userid;
		this.title = title;
		this.content = content;
		this.hit = hit;
		this.regtime = regtime;
	}


	public int getArticleno() {
		return articleno;
	}


	public void setArticleno(int articleno) {
		this.articleno = articleno;
	}


	public String getUserid() {
		return userid;
	}


	public void setUserid(String userid) {
		this.userid = userid;
	}




	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getContent() {
		return content;
	}


	public void setContent(String content) {
		this.content = content;
	}


	public int getHit() {
		return hit;
	}


	public void setHit(int hit) {
		this.hit = hit;
	}


	public String getRegtime() {
		return regtime;
	}


	public void setRegtime(String regtime) {
		this.regtime = regtime;
	}


	@Override
	public String toString() {
		return "BoardDTO [articleno=" + articleno + ", userid=" + userid + ", title=" + title + ", content="
				+ content + ", hit=" + hit + ", regtime=" + regtime + "]";
	}
	
	
}
