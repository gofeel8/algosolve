package com.ssafy.board.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ssafy.board.dao.BoardDAO;
import com.ssafy.board.dto.BoardDTO;

@Component
public class BoardServiceImpl implements BoardService {
	
	@Autowired
	BoardDAO dao;

	@Override
	public int createBoard(BoardDTO board) {
		return dao.insertBoard(board);
	}

	@Override
	public List<BoardDTO> searchAll() {
		return dao.selectAllBoard();
	}

	@Override
	public BoardDTO search(int no) {
		return dao.selectBoard(no);
	}

	@Override
	public void edit(BoardDTO board) {
		dao.updateBoard(board);
	}

	@Override
	public void remove(int no) {
		dao.deleteBoard(no);
		
	}

}
