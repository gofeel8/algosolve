create database shopping;

use shopping;

create table if not exists user(
id int not null auto_increment,
name varchar(20) not null,
address varchar(100) not null,
number1 varchar(20) not null,
number2 varchar(20) null,
Primary key(id));


create table if not exists product(
id int not null auto_increment,
name varchar(30) not null,
price int not null,
stock int not null,
Primary key(id));


create table if not exists `order`(
id int not null auto_increment,
user int ,
product int,
quantity int not null,
ammount int not null,
status varchar(20),
delivery varchar(20),
Primary key(id),
foreign key (user)  REFERENCES `user` (`id`) ON DELETE set null ON UPDATE cascade,
foreign key (product)  REFERENCES `product` (`id`) ON DELETE set null ON UPDATE cascade
);


