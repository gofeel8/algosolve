var burger = function() {
	$('#clicked').attr('src',"./images/burger.jpg");
	$('#name').html("오늘의 메뉴 : 햄버거");
	$("footer img").attr('style','border : 0px');
	$('footer img[src="./images/burger.jpg"]').attr('style','border : 2px solid black; opacity : 1;')
	
}

$(".list[src='./images/burger.jpg'").click(burger);

var cake = function() {
	$('#clicked').attr('src',"./images/cake.jpg");
	$('#name').html("오늘의 메뉴 : 케이크");
	$("footer img").attr('style','border : 0px');
	$('footer img[src="./images/cake.jpg"]').attr('style','border : 2px solid black; opacity : 1;')
	
};

$(".list[src='./images/cake.jpg'").click(cake);


var sandwich =function() {
	$('#clicked').attr('src',"./images/sandwich.jpg");
	$('#name').html("오늘의 메뉴 : 샌드위치");
	$("footer img").attr('style','border : 0px');
	$('footer img[src="./images/sandwich.jpg"]').attr('style','border : 2px solid black; opacity : 1;')
	
}

$(".list[src='./images/sandwich.jpg'").click(sandwich);


var steak =function() {
	$('#clicked').attr('src',"./images/steak.jpg");
	$('#name').html("오늘의 메뉴 : 스테이크");
	$("footer img").attr('style','border : 0px');
	$('footer img[src="./images/steak.jpg"]').attr('style','border : 2px solid black; opacity : 1;')
	
};
$(".list[src='./images/steak.jpg'").click(steak);


$("#rand").click(function (){
	var num = Math.floor(Math.random()*4);
	switch (num){
	case 0:
		burger();
		break;
	case 1:
		cake();
		break;
	case 2:
		sandwich();
		break;
	case 3:
		steak();
		break;
	}
})

