package day0330;

public class AptDeal {
	private String aptName;  //<아파트>
	private String dong;   //<법정동>
	private String dealAmount;  //<거래금액>
	
	
	public AptDeal() {
		super();
	}
	public AptDeal(String aptName, String dong, String dealAmount) {
		super();
		this.aptName = aptName;
		this.dong = dong;
		this.dealAmount = dealAmount;
	}
	@Override
	public String toString() {
		return "아파트 명 :" + aptName + ", 법정동 :" + dong + ", 거래금액 :" + dealAmount ;
	}
	public String getAptName() {
		return aptName;
	}
	public void setAptName(String aptName) {
		this.aptName = aptName;
	}
	public String getDong() {
		return dong;
	}
	public void setDong(String dong) {
		this.dong = dong;
	}
	public String getDealAmount() {
		return dealAmount;
	}
	public void setDealAmount(String dealAmount) {
		this.dealAmount = dealAmount;
	}
	
	
}
