package day0330;

import java.util.ArrayList;
import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		AptDealDomparser parser = new AptDealDomparser();
		System.out.print("찾으시는 아파트를 입력하세요 : ");
		Scanner sc = new Scanner(System.in);
		String apt = sc.nextLine();
		
		ArrayList<AptDeal> find;
		find = parser.findList(apt);
		for(AptDeal tmp : find) {
			System.out.println(tmp);
		}

	}

}
