package day0330;

import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


public class AptDealDomparser {
	private ArrayList<AptDeal> list;

	public AptDealDomparser() {
		list = new ArrayList<AptDeal>();
		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder;
		
		
		try {
			builder=factory.newDocumentBuilder();
			Document doc = builder.parse("AptDealHistory.xml");
			doc.getDocumentElement().normalize();
			NodeList item = doc.getElementsByTagName("item");
			for(int i=0;i<item.getLength();i++) {
				AptDeal temp = new AptDeal();
				NodeList detail = item.item(i).getChildNodes();
				for(int j=0;j<detail.getLength();j++) {
					if(detail.item(j).getNodeType()==Element.ELEMENT_NODE) {
						if(detail.item(j).getNodeName().equals("아파트")) {
							temp.setAptName(detail.item(j).getTextContent());
							list.add(temp);
						}
						else if(detail.item(j).getNodeName().equals("법정동")) {
							temp.setDong(detail.item(j).getTextContent());
						}
						else if(detail.item(j).getNodeName().equals("거래금액")) {
							temp.setDealAmount(detail.item(j).getTextContent());
						}
					}
				}
			}
			
//			for(AptDeal temp : list) {
//				System.out.println(temp);
//			}
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public ArrayList<AptDeal> getList() {
		return list;
	}

	public void setList(ArrayList<AptDeal> list) {
		this.list = list;
	}
	
	public ArrayList<AptDeal> findList(String apt) {
		ArrayList<AptDeal> rt = new ArrayList<AptDeal>();
		for(AptDeal tmp : list) {
			if(tmp.getAptName().indexOf(apt) != -1) {
				rt.add(tmp);
			}
		}
		return rt;
	}

}
