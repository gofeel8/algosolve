package com.ssafy.product.dto;

public class Product {
	String title;
	int price;
	String desc;
	public Product(String title, int price, String desc) {
		super();
		this.title = title;
		this.price = price;
		this.desc = desc;
	}
	public Product() {
		super();
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	@Override
	public String toString() {
		return "Product [title=" + title + ", price=" + price + ", desc=" + desc + "]";
	}
	
	

}
