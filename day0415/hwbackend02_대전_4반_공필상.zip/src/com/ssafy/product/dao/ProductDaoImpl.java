package com.ssafy.product.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.ssafy.product.dto.Product;
import com.ssafy.product.util.DBUtil;

public class ProductDaoImpl implements ProductDao {

	@Override
	public int insertProduct(Product product) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("insert into product(title,price,desc)");
			sql.append("VALUES(?,?,?)");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, product.getTitle());
			pstmt.setInt(2, product.getPrice());
			pstmt.setString(3, product.getDesc());
			return pstmt.executeUpdate();
		}finally {
			if(conn != null)DBUtil.close(conn);
			if(pstmt != null)DBUtil.close(pstmt);
		}

	}

}
