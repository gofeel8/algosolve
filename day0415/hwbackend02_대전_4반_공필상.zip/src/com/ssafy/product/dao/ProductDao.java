package com.ssafy.product.dao;

import java.sql.SQLException;

import com.ssafy.product.dto.Product;

public interface ProductDao {
	public int insertProduct(Product product) throws SQLException;

}
