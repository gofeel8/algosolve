package com.ssafy.product.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.product.dto.Product;
import com.ssafy.product.util.DBUtil;

public class ProductDaoImpl implements ProductDao {

	@Override
	public void insertProduct(Product product) throws SQLException {
		Connection conn =null;
		PreparedStatement pstmt = null;
		try {
		conn = DBUtil.getConnection();
		StringBuilder insertProduct = new StringBuilder();
		System.out.println(product);
		insertProduct.append("insert into product (title,price,descrip) values (?, ?, ?)");
//		insertProduct.append("values (?, ?, ?)");
		pstmt = conn.prepareStatement(insertProduct.toString());
		pstmt.setString(1, product.getTitle());
		pstmt.setInt(2, product.getPrice());
		pstmt.setString(3, product.getDesc());
		pstmt.executeUpdate();
		}finally {
			if(conn!=null)
				DBUtil.close(conn);
			if(pstmt != null)
				DBUtil.close(pstmt);
		}
	}

	@Override
	public List<Product> selectAll() throws SQLException {
		List<Product> list = new ArrayList<Product>();
		
		Connection conn =null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
		conn = DBUtil.getConnection();
		StringBuilder selectAll = new StringBuilder();
		selectAll.append("select * from product");
		pstmt = conn.prepareStatement(selectAll.toString());
		rs=pstmt.executeQuery();
		while(rs.next()) {
			Product tmp = new Product(rs.getString(1), rs.getInt(2), rs.getString(3));
			list.add(tmp);
		}
		}finally {
			if(conn!=null)
				DBUtil.close(conn);
			if(pstmt != null)
				DBUtil.close(pstmt);
			if(rs != null)
				DBUtil.close(rs);
		}
		return list;
	}

}
