package com.ssafy.product.dao;

import java.sql.SQLException;

import com.ssafy.product.dto.User;


public interface UserDao {
	public User select(String userid, String userpwd) throws SQLException;

}
