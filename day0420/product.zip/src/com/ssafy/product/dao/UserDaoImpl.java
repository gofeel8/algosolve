package com.ssafy.product.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.ssafy.product.dto.User;
import com.ssafy.product.util.DBUtil;

public class UserDaoImpl implements UserDao {

	@Override
	public User select(String userid, String userpwd) throws SQLException {
		User user = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		conn = DBUtil.getConnection();
		StringBuilder sql = new StringBuilder();
		sql.append("select username, userid, email \n");
		sql.append("from user \n");
		sql.append("where userid = ? and userpwd = ?");
		pstmt = conn.prepareStatement(sql.toString());
		pstmt.setString(1, userid);
		pstmt.setString(2, userpwd);
		rs = pstmt.executeQuery();
		if(rs.next()) {
			user = new User();
			user.setUserid(rs.getString("userid"));
			user.setUsername(rs.getString("username"));
			user.setEmail(rs.getString("email"));
		}
		return user;
	}

}
