package com.ssafy.product.dao;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.product.dto.Product;


public interface ProductDao {
	public void insertProduct(Product product) throws SQLException;
	public List<Product> selectAll() throws SQLException;

}
