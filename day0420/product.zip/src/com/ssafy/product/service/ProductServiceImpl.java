package com.ssafy.product.service;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.product.dao.ProductDao;
import com.ssafy.product.dao.ProductDaoImpl;
import com.ssafy.product.dto.Product;

public class ProductServiceImpl implements ProductService {
	private ProductDao dao;
	
	public ProductServiceImpl() {
		dao = new ProductDaoImpl();
	}
	@Override
	public boolean insertProduct(Product product) {
		try {
			dao.insertProduct(product);
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public List<Product> selectAll() {
		try {
			return dao.selectAll();
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}


}
