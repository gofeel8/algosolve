package com.ssafy.product.service;

import com.ssafy.product.dto.User;

public interface LoginService {
	public User login(String userid, String userpwd) throws Exception;
	
}
