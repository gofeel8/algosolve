package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.dto.MemberDTO;
import model.service.MemberService;
import model.service.MemberServiceImpl;

@WebServlet("/member.do")
public class MemberController extends HttpServlet{
	private MemberService memberService;
	
	@Override
	public void init() throws ServletException {
		memberService = new MemberServiceImpl();
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		process(req,resp);
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");
		resp.setCharacterEncoding("UTF-8");
		resp.setContentType("text/html; charset=utf-8");
		process(req,resp);
	}
	
	private void process(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String command=req.getParameter("command");
		System.out.println("command = "+command);
		if(command.equals("mvjoin")) {
			String path = "/member/join.jsp";
			req.getRequestDispatcher(path).forward(req, resp);
		}else if(command.equals("join")) {
			join(req,resp);
		}else if(command.equals("idchk")) {
			idchk(req,resp);
		}else if(command.equals("mvlogin")) {
			String path = "/member/login.jsp";
			req.getRequestDispatcher(path).forward(req, resp);
		}else if(command.equals("login")) {
			login(req,resp);
		}else if(command.equals("logout")) {
			logout(req, resp);
		}
	}

	private void logout(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession();
		session.invalidate();
		String path = "/index.jsp";
		forward(req, resp, path);
		
	}

	private void login(HttpServletRequest req, HttpServletResponse resp){
		String id =req.getParameter("id");
		String pwd =req.getParameter("pwd");
		MemberDTO member =  memberService.login(id, pwd);
		String path = null;
		if(member != null) {
			HttpSession session = req.getSession();
			session.setAttribute("userinfo", member);
			path = "/index.jsp";
//			forward(req, resp, path);
			System.out.println("이동해라~!~!!~");
			System.out.println(member);
		}else {
			System.out.println("없는 아이디 ");
			PrintWriter writer;
			try {
				writer = resp.getWriter();
				writer.write("false");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return;
		}
		
		try {
			path = "/index.jsp";
			req.getRequestDispatcher(path).forward(req, resp);
			System.out.println("이동을 안해 ㅜ");
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}

	private void idchk(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		String id = req.getParameter("mbr_id");
		PrintWriter writer = resp.getWriter();
		int num = memberService.IdCheck(id);
		System.out.println("num="+num);
			writer.write(Integer.toString(num));
		
	}

	private void join(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("mbr_id");
		String password = request.getParameter("mbr_pwd");
		String name = request.getParameter("mbr_nm");
		String tel = request.getParameter("mbr_tel");
		String email = request.getParameter("mbr_email");
		String addr = request.getParameter("mbr_addr");
		
		MemberDTO member = new MemberDTO();
		member.setUserid(id);
		member.setUserpwd(password);
		member.setUsername(name);
		member.setTelephone(tel);
		member.setEmail(email);
		member.setAddress(addr);
		
		if(memberService.insertMember(member)) {
			String path = "/index.jsp";
			forward(request, response, path);
		}else {
			error(request, response, "회원가입 오류!!!");
		}
	}

	private void forward(HttpServletRequest request, HttpServletResponse response, String path) throws ServletException, IOException {
		request.getRequestDispatcher(path).forward(request, response);	
	}
	
	private void error(HttpServletRequest request, HttpServletResponse response, String msg) throws ServletException, IOException {
		request.setAttribute("msg", msg);
		String path = "/error/error.jsp";
		forward(request, response, path);
	}

}
