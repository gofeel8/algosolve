package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import model.dto.BoardDTO;
import model.service.BoardService;
import model.service.BoardServiceImpl;

@WebServlet("/board.do")
public class BoardController extends HttpServlet{
	private BoardService boardService;
	
	@Override
	public void init() throws ServletException {
		boardService = new BoardServiceImpl();
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		process(req,resp);
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setCharacterEncoding("UTF-8");
		resp.setContentType("text/html; charset=utf-8");
		process(req,resp);
	}

	private void process(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String command=req.getParameter("command");
//		System.out.println("command = "+command);
		if(command.equals("mvlist")) {
			String path = "/board/list.jsp";
			req.getRequestDispatcher(path).forward(req, resp);
		}else if(command.equals("list")) {
			list(req,resp);
		}else if(command.equals("mvwrite")) {
			String path = "/board/write.jsp";
			req.getRequestDispatcher(path).forward(req, resp);
		}else if(command.equals("write")) {
			boardWrite(req,resp);
		}
		
	}

	private void list(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		List<BoardDTO> list = boardService.getBoardList();
		PrintWriter writer = resp.getWriter();
		Gson gson = new Gson();
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("blist", list);
		writer.write(gson.toJson(map));
		
	}

	private void boardWrite(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String id = req.getParameter("userid");
		String title = req.getParameter("btitle");
		String content = req.getParameter("bcontent");
		BoardDTO board = new BoardDTO();
		board.setUserid(id);
		board.setSubject(title);
		board.setContent(content);
		if(boardService.writeBoard(board)) {
			String path = "/board/list.jsp";
			req.getRequestDispatcher(path).forward(req, resp);
		}else {
			//실패
		}
		
		
		
	}
	

}
