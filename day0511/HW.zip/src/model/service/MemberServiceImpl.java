package model.service;

import java.sql.SQLException;

import model.dao.MemberDAO;
import model.dao.MemberDAOImpl;
import model.dto.MemberDTO;

public class MemberServiceImpl implements MemberService {
	private MemberDAO dao;

	public MemberServiceImpl() {
		dao = new MemberDAOImpl();
	}
	
	@Override
	public boolean insertMember(MemberDTO member) {
		try {
			dao.insertMember(member);
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public MemberDTO login(String id, String pwd) {
		MemberDTO rt = null;
		try {
			rt = dao.login(id, pwd);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rt;
	}

	@Override
	public int IdCheck(String id) {
		int rt = 0;
		try {
			rt = dao.IdCheck(id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			rt=0;
		}
		return rt;
	}

}
