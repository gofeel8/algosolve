package model.service;

import model.dto.MemberDTO;

public interface MemberService {
	//insert(dto);
	public boolean insertMember(MemberDTO member);
	//select(id)
	public MemberDTO login(String id,String pwd);
	//idcheck
	public int IdCheck(String id);
	//delete(id)
	//update(dto)

}
