package model.service;

import java.sql.SQLException;
import java.util.List;

import model.dao.BoardDAO;
import model.dao.BoardDAOImpl;
import model.dto.BoardDTO;

public class BoardServiceImpl implements BoardService{
	private BoardDAO dao;
	
	public BoardServiceImpl() {
		dao = new BoardDAOImpl();
	}

	@Override
	public List<BoardDTO> getBoardList() {
		List<BoardDTO> rt = null;
		try {
			rt = dao.getBoardList();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rt;
	}

	@Override
	public boolean writeBoard(BoardDTO board){
		boolean rt = false;
		try {
			rt = dao.writeBoard(board);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rt;
	}

	@Override
	public boolean deleteBoard(int no) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateBoard(BoardDTO board) {
		// TODO Auto-generated method stub
		return false;
	}

}
