package model.service;

import java.sql.SQLException;
import java.util.List;

import model.dto.BoardDTO;

public interface BoardService {
	List<BoardDTO> getBoardList();
	boolean writeBoard(BoardDTO board);
	boolean deleteBoard(int no);
	boolean updateBoard(BoardDTO board);

}
