package model.dao;

import java.sql.SQLException;
import java.util.List;

import model.dto.BoardDTO;

public interface BoardDAO {
	List<BoardDTO> getBoardList() throws SQLException;
	boolean writeBoard(BoardDTO board) throws SQLException;
	boolean deleteBoard(int no);
	boolean updateBoard(BoardDTO board);
}
