package model.dao;

import java.sql.SQLException;

import model.dto.MemberDTO;

public interface MemberDAO {
	//insert(dto);
	public void insertMember(MemberDTO member) throws SQLException;
	//select(id)
	public MemberDTO login(String id,String pwd) throws SQLException;
	//idcheck
	public int IdCheck(String id) throws SQLException;
	//delete(id)
	//update(dto)

}
