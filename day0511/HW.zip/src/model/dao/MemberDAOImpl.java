package model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.dto.MemberDTO;
import util.DBUtil;

public class MemberDAOImpl implements MemberDAO {

	@Override
	public void insertMember(MemberDTO member) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("insert into ssafy_member2 \n");
			sql.append("(userid,username,userpwd,telephone,email,address,joindate) \n");
			sql.append("values (?,?,?,?,?,?,now())");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, member.getUserid());
			pstmt.setString(2, member.getUsername());
			pstmt.setString(3, member.getUserpwd());
			pstmt.setString(4, member.getTelephone());
			pstmt.setString(5, member.getEmail());
			pstmt.setString(6, member.getAddress());
			pstmt.execute();
		}finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		
	}

	@Override
	public MemberDTO login(String id, String pwd) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		MemberDTO dto =null;
		try {
			conn= DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select userno,userid,username,telephone,email,address from ssafy_member2 \n");
			sql.append("where userid = ? and userpwd = ?");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, id);
			pstmt.setString(2, pwd);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				dto = new MemberDTO();
				dto.setUserno(rs.getInt("userno"));
				dto.setUserid(rs.getString("userid"));
				dto.setUsername(rs.getString("username"));
				dto.setTelephone(rs.getString("telephone"));
				dto.setEmail(rs.getString("email"));
				dto.setAddress(rs.getString("address"));
			}
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);	
		}
		
		return dto;
	}

	@Override
	public int IdCheck(String id) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int idCount = 0;
		try {
			conn = DBUtil.getConnection();
			StringBuilder insertMember = new StringBuilder();
			insertMember.append("SELECT count(*) cnt FROM ssafy_member2 \n");
			insertMember.append("WHERE userid = ?");
			pstmt = conn.prepareStatement(insertMember.toString());
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				idCount = rs.getInt("cnt");
			}
		}  finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return idCount;
	}


}
