package model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.dto.BoardDTO;
import util.DBUtil;

public class BoardDAOImpl implements BoardDAO {
	

	@Override
	public List<BoardDTO> getBoardList() throws SQLException {
		Connection conn =null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<BoardDTO> rt = new ArrayList<>();
		try {
			conn=DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select * from guestbook");
			pstmt = conn.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			while(rs.next()) {
				BoardDTO board = new BoardDTO();
				board.setArticleno(Integer.parseInt(rs.getString("articleno")));
				board.setSubject(rs.getString("subject"));
				board.setContent(rs.getString("content"));
				board.setUserid(rs.getString("userid"));
				board.setRegtime(rs.getString("regtime"));
				rt.add(board);
			}
		}finally {
			DBUtil.close(conn);
			DBUtil.close(pstmt);
		}
		return rt;
	}

	@Override
	public boolean writeBoard(BoardDTO board) throws SQLException {
		Connection conn =null;
		PreparedStatement pstmt = null;
		boolean rt;
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("insert into guestbook(userid,subject,content,regtime) VALUES(?,?,?,now())");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, board.getUserid());
			pstmt.setString(2, board.getSubject());
			pstmt.setString(3, board.getContent());
			rt = pstmt.execute();
		} finally {
			DBUtil.close(conn);
			DBUtil.close(pstmt);
		}
		
		return rt;
	}

	@Override
	public boolean deleteBoard(int no) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateBoard(BoardDTO board) {
		// TODO Auto-generated method stub
		return false;
	}

}
