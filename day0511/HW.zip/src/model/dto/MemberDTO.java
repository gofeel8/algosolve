package model.dto;

public class MemberDTO {
	int userno;
	String userid; 
	String username;
	String userpwd;
	String telephone; 
	String email;
	String address; 
	String joindate;
	
	public MemberDTO(String userid, String username, String userpwd, String telephone, String email, String address) {
		super();
		this.userid = userid;
		this.username = username;
		this.userpwd = userpwd;
		this.telephone = telephone;
		this.email = email;
		this.address = address;
	}
	
	

	public MemberDTO() {
		super();
	}



	public int getUserno() {
		return userno;
	}

	public void setUserno(int userno) {
		this.userno = userno;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUserpwd() {
		return userpwd;
	}

	public void setUserpwd(String userpwd) {
		this.userpwd = userpwd;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getJoindate() {
		return joindate;
	}

	public void setJoindate(String joindate) {
		this.joindate = joindate;
	}

	@Override
	public String toString() {
		return "MemberDTO [userno=" + userno + ", userid=" + userid + ", username=" + username + ", userpwd=" + userpwd
				+ ", telephone=" + telephone + ", email=" + email + ", address=" + address + ", joindate=" + joindate
				+ "]";
	}
	
	
}
