package test;


import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ssafy.model.dto.Product;
import com.ssafy.model.service.ProductService;

public class Test {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = 
				new ClassPathXmlApplicationContext("file:src/main/webapp/WEB-INF/spring/applicationContext.xml");
		ProductService service=(ProductService) context.getBean("productService");
		service.selectAll();
		service.insert(new Product());
		service.select("gps");
		service.delete("gps");
		service.update(new Product());

	}

}
