package com.ssafy.model.dto;

public class Product {
	String no;
	String name;
	String comp;
	int price;
	String desc;
	
	public Product() {
		super();
	}
	
	public Product(String no, String name, String comp, int price, String desc) {
		super();
		this.no = no;
		this.name = name;
		this.comp = comp;
		this.price = price;
		this.desc = desc;
	}

	@Override
	public String toString() {
		return "Product [no=" + no + ", name=" + name + ", comp=" + comp + ", price=" + price + ", desc=" + desc + "]";
	}
	public String getNo() {
		return no;
	}

	public void setNo(String no) {
		this.no = no;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getComp() {
		return comp;
	}
	public void setComp(String comp) {
		this.comp = comp;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	
}
