package com.ssafy.model.repository;

import java.util.List;

import com.ssafy.model.dto.Product;

public class ProductRepoImpl implements ProductRepo {

	@Override
	public List<Product> selectAll() {
		System.out.println("제품 모두 불러오기 성공");
		return null;
	}

	@Override
	public Product select(String id) {
		System.out.println("제품명  :" +id+" 불러오기 성공");
		return null;
	}

	@Override
	public int insert(Product product) {
		System.out.println("제품 추가 성공");
		return 0;
	}

	@Override
	public int update(Product product) {
		System.out.println("업데이트 성공");
		return 0;
	}

	@Override
	public int delete(String id) {
		System.out.println("삭제 성공");
		return 0;
	}

}
