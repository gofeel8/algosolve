package com.ssafy.product.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ssafy.product.dto.Product;
import com.ssafy.product.service.ProductService;


@Controller
public class ProductController {
	@Autowired
	ProductService service;
	
	@RequestMapping("/")
	public String list(Model model) {
		
		model.addAttribute("products", service.selectAll(null, null));
		return "list";
	}
	@RequestMapping("/enrollForm")
	public String enrollForm(Model model) {
		return "enroll";
	}
	
	@RequestMapping("/enroll")
	public String enroll(Product p) {
		service.insertProduct(p);
		return "redirect:/";
	}
	
	

}
