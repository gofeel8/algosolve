package com.ssafy.product.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.ssafy.product.dto.Product;
import com.ssafy.product.util.DBUtil;

@Component
public class ProductDaoImpl implements ProductDao {

	@Override
	public void insertProduct(Product product) throws SQLException {
		Connection conn =null;
		PreparedStatement pstmt = null;
		try {
		conn = DBUtil.getConnection();
		StringBuilder insertProduct = new StringBuilder();
		System.out.println(product);
		insertProduct.append("insert into product (title,price,descrip) values (?, ?, ?)");
//		insertProduct.append("values (?, ?, ?)");
		pstmt = conn.prepareStatement(insertProduct.toString());
		pstmt.setString(1, product.getTitle());
		pstmt.setInt(2, product.getPrice());
		pstmt.setString(3, product.getDesc());
		pstmt.executeUpdate();
		}finally {
			if(conn!=null)
				DBUtil.close(conn);
			if(pstmt != null)
				DBUtil.close(pstmt);
		}
	}

	@Override
	public List<Product> selectAll(String key,String word) throws SQLException {
		List<Product> list = new ArrayList<Product>();
		
		Connection conn =null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
		conn = DBUtil.getConnection();
		StringBuilder selectAll = new StringBuilder();
		selectAll.append("select * from product\n");
		if(!word.isEmpty()) {
			if(key.equals("maxprice")) {
				selectAll.append("where price <= ?");
			}else if(key.equals("producttitle")) {
				selectAll.append("where title like ?");
			}
		}
		pstmt = conn.prepareStatement(selectAll.toString());
		if(!word.isEmpty()) {
			if(key.equals("maxprice")) {
				pstmt.setInt(1,Integer.parseInt(word));
			}else if(key.equals("producttitle")) {
				pstmt.setString(1, "%"+word+"%");
			}
		}		
		rs=pstmt.executeQuery();
		while(rs.next()) {
			Product tmp = new Product(rs.getInt(1),rs.getString(2), rs.getInt(3), rs.getString(4));
			list.add(tmp);
		}
		}finally {
			if(conn!=null)
				DBUtil.close(conn);
			if(pstmt != null)
				DBUtil.close(pstmt);
			if(rs != null)
				DBUtil.close(rs);
		}
		return list;
	}

	@Override
	public Product selectNo(int no) throws SQLException {
		Product temp = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = DBUtil.getConnection();
			String sql="SELECT * FROM PRODUCT WHERE NUM=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, no);
			rs = pstmt.executeQuery();
			if(rs.next() != false) {
				temp = new Product(rs.getInt("NUM"), rs.getString("TITLE"), rs.getInt("PRICE"), rs.getString("DESCRIP"));
			}
		}finally {
			DBUtil.close(conn);
			DBUtil.close(pstmt);
			DBUtil.close(rs);
		}
		
		return temp;
	}

	@Override
	public void delete(int no) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = DBUtil.getConnection();
			String sql="DELETE FROM PRODUCT WHERE NUM=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, no);
			pstmt.execute();
		}finally {
			DBUtil.close(conn);
			DBUtil.close(pstmt);
		}
	}

	@Override
	public void fix(int no,Product product) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = DBUtil.getConnection();
			String sql="UPDATE PRODUCT SET TITLE=?,PRICE=?,DESCRIP=? WHERE NUM=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, product.getTitle());
			pstmt.setInt(2, product.getPrice());
			pstmt.setString(3, product.getDesc());
			pstmt.setInt(4, no);
			pstmt.execute();
		}finally {
			DBUtil.close(conn);
			DBUtil.close(pstmt);
		}
	}

}
