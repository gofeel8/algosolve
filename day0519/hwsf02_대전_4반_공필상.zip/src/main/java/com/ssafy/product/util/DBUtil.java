package com.ssafy.product.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	static final String url = "jdbc:mysql://127.0.0.1:3305/product_db?serverTimezone=UTC&useUniCode=yes&useSSL=false&characterEncoding=UTF-8";
	static final String driver="com.mysql.cj.jdbc.Driver";
	static final String id="ssafy";
	static final String password="ssafy";
	
	static {
		try {
			Class.forName(driver);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static Connection getConnection() throws SQLException{
		return DriverManager.getConnection(url,id,password);
	}
	
	public static void close(AutoCloseable c) {
		try {
			c.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
