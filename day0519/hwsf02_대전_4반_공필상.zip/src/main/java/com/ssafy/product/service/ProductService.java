package com.ssafy.product.service;

import java.util.List;

import com.ssafy.product.dto.Product;


public interface ProductService {
	public boolean insertProduct(Product product);
	public List<Product> selectAll(String key,String word);
	public Product selectNo(int no);
	public boolean delete(int no);
	public boolean fix(int no,Product product);
}
