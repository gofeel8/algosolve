package com.ssafy.product.service;

import java.util.List;

import com.ssafy.product.dto.Product;


public interface ProductService {
	public int insertProduct(Product product);
	public List<Product> selectAll();
	public Product selectNo(int no);
	public int delete(int no);
	public int fix(Product product);
}
