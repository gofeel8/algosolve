package com.ssafy.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.product.dto.Product;
import com.ssafy.product.service.ProductService;


@RestController
public class ProductController {
	@Autowired
	ProductService service;
	
	@RequestMapping("/all")
	public List<Product> list(Model model) {
		return service.selectAll();
	}
	

	@PostMapping("/")  
	public String regist(Product product) {	
		System.out.println("입력 상품>>>"+ product);		
		int  t=  service.insertProduct(product);
		if(t==1) {
			return "success";
		}else {
			return "fail";
		}
	}//사람등록  :  http://localhost:8080/person   + POST
	
	
	@GetMapping("/{no}")  
	public Product list(@PathVariable("no") int no) {
		System.out.println("수정 번호>>>"+ no);
		return service.selectNo(no);
	}//수정폼데이터 조회  :  http://localhost:8080/person/13   + GET
	
	@PutMapping("/")  
	public String modify(@RequestBody Product product) {
		System.out.println("수정 상품>>>"+ product);
		if(service.fix(product)==1) return "success";
		else return "fail";		
	}//사람수정  :  http://localhost:8080/person/3   + PUT
	
	
	@DeleteMapping("/{no}")  
	public String remove(@PathVariable("no") Integer no) {	
		if(service.delete(no)==1) return "success";
		else return "fail";		
	}//사람삭제  :  http://localhost:8080/person/3   + DELETE
	

}
