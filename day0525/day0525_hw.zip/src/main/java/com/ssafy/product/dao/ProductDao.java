package com.ssafy.product.dao;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.product.dto.Product;


public interface ProductDao {
	public int insertProduct(Product product) ;
	public List<Product> selectAll() ;
	public Product selectNo(int no) ;
	public int delete(int no);
	public int fix(Product product);

}
