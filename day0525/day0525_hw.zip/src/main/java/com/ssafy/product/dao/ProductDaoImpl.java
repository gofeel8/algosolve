package com.ssafy.product.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ssafy.product.dto.Product;

@Component
public class ProductDaoImpl implements ProductDao {
	
	@Autowired
	SqlSession sqlSession;

	@Override
	public int insertProduct(Product product) {
		return sqlSession.insert("product.insert",product);
		
	}

	@Override
	public List<Product> selectAll()  {
		return sqlSession.selectList("product.selectAll");
	}

	@Override
	public Product selectNo(int no) {
		return sqlSession.selectOne("product.select",no);
	}

	@Override
	public int delete(int no) {
		return sqlSession.delete("product.delete",no);
	}

	@Override
	public int fix(Product product) {
		return sqlSession.update("product.update",product);
		
	}

}
