package com.ssafy.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ssafy.product.dao.ProductDao;
import com.ssafy.product.dto.Product;

@Component
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	private ProductDao dao;
	
	@Override
	public int insertProduct(Product product) {
		return dao.insertProduct(product);
	}

	@Override
	public List<Product> selectAll() {
		return dao.selectAll();
	}

	@Override
	public Product selectNo(int no) {
		return dao.selectNo(no);
	}

	@Override
	public int delete(int no) {
		 return dao.delete(no);
	}

	@Override
	public int fix(Product product) {
		return dao.fix(product);
	}


}
