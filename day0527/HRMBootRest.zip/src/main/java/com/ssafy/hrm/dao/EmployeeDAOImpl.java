package com.ssafy.hrm.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.hrm.dto.Employee;

@Repository
public class EmployeeDAOImpl implements EmployeeDAO{

	@Autowired
	private SqlSession sqlSession;
	
	@Override
	public List<Employee> findAllEmployees() throws Exception {
		Employee temp = new Employee();
		return sqlSession.selectList("s_emp.select",temp);
	}
	

	@Override
	public int addEmployee(Employee emp) throws Exception {
		System.out.println("emp:"+emp);
		return sqlSession.insert("s_emp.insert",emp);
	}


	@Override
	public List<Employee> findEmployeeByDept(int no) throws Exception {
		Employee temp = new Employee();
		temp.setDept_id(no);
		return sqlSession.selectList("s_emp.select",temp);
	}
	@Override
	public Employee findEmployeeById(int id) throws Exception {
		Employee temp = new Employee();
		temp.setId(id);
		return sqlSession.selectOne("s_emp.select",temp);
	}

	@Override
	public boolean updateEmployee(Employee emp) throws Exception {
		 sqlSession.update("s_emp.update",emp);
		 return true;
	}

	@Override
	public boolean deleteEmployee(int no) throws Exception {
		System.out.println("no="+no);
		sqlSession.delete("s_emp.delete",no);
		 return true;
	}

	
}
