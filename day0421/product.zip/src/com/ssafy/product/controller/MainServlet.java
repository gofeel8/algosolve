package com.ssafy.product.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ssafy.product.dto.Product;
import com.ssafy.product.dto.User;
import com.ssafy.product.service.LoginService;
import com.ssafy.product.service.LoginServiceImpl;
import com.ssafy.product.service.ProductService;
import com.ssafy.product.service.ProductServiceImpl;


@WebServlet("/main.do")
public class MainServlet extends HttpServlet {
	private LoginService loginService;
	private ProductService productService;
	

	@Override
	public void init() throws ServletException {
		loginService = new LoginServiceImpl();
		productService = new ProductServiceImpl();
	}
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		process(request, response);
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		process(request, response);
	}
	
	private void process(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String act = request.getParameter("act");
		if (act.equals("login")) {
			login(request, response);
		} else if (act.equals("logout")) {
			logout(request, response);
		} else if (act.equals("enroll")) {
			enroll(request, response);
		} else if (act.equals("enrollform")) {
			enrollform(request, response);
		}else if (act.equals("list")) {
			list(request, response);
		}else if (act.equals("last")) {
			last(request, response);
		}else if (act.equals("detail")) {
			detail(request, response);
		}else if (act.equals("mvfix")) {
			mvfix(request, response);
		}else if (act.equals("fix")) {
			fix(request, response);
		}else if (act.equals("delete")) {
			delete(request, response);
		}
	}
	


	private void delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/main.do?act=list";
		int no = Integer.parseInt(request.getParameter("productno"));
		productService.delete(no);
		request.getRequestDispatcher(path).forward(request, response);
	}

	private void fix(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/main.do?act=list";
		int no = Integer.parseInt(request.getParameter("productno"));
		String title = request.getParameter("title");
		String price = request.getParameter("price");
		String desc = request.getParameter("desc");
		Product product = new Product(title, Integer.parseInt(price), desc);
		if(productService.fix(no,product)) {
			System.out.println("성공");
		}else {
			System.out.println("실패");
		}
		request.getRequestDispatcher(path).forward(request, response);
	}

	private void mvfix(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/product/fix.jsp";
		int no = Integer.parseInt(request.getParameter("productno"));
		Product temp = productService.selectNo(no);
		request.setAttribute("product", temp);
		request.getRequestDispatcher(path).forward(request, response);
		
	}

	private void detail(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/product/detail.jsp";
		int no = Integer.parseInt(request.getParameter("productno"));
		Product temp = productService.selectNo(no);
		request.setAttribute("product", temp);
		request.getRequestDispatcher(path).forward(request, response);
	}

	private void last(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String title="",price="",desc="";
		Cookie[] cookies = request.getCookies();         
		for(int i = 0 ; cookies !=null && i<cookies.length; i++){   
			if(cookies[i].getName().equals("lastTitle")) {
				title = cookies[i].getValue();
			}
			if(cookies[i].getName().equals("lastPrice")) {
				price= cookies[i].getValue();
			}
			if(cookies[i].getName().equals("lastDesc")) {
				desc= cookies[i].getValue();
			}
		}
		if(title.equals("")||price.equals("")||desc.equals("")) {
			response.setContentType("text/html;charset=utf-8");
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('최근에 추가한 상품이 없습니다.');");
			out.println("history.back();");
			out.println("</script>");
		}else {
			request.setAttribute("title", title);
			request.setAttribute("price", price);
			request.setAttribute("desc", desc);
			request.getRequestDispatcher("/product/last.jsp").forward(request, response);
		}
		
	}

	private void list(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path ="/product/list.jsp";
		String key = request.getParameter("key");
		String word = request.getParameter("word");
		
		List<Product> list = productService.selectAll(key,word);
		
		request.setAttribute("products", list);
		request.getRequestDispatcher(path).forward(request, response);
	}

	private void enrollform(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = "/product/enroll.jsp";
		request.getRequestDispatcher(path).forward(request, response);
	}

	private void enroll(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String root = request.getContextPath();
		String path = "/product/enroll.jsp";
		String title = request.getParameter("title");
		String price = request.getParameter("price");
		String desc = request.getParameter("desc");
		Product product = new Product(title, Integer.parseInt(price), desc);
		if (productService.insertProduct(product)== false) {
			response.setContentType("text/html;charset=utf-8");
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('상품등록에 실패하였습니다.!!!');");
			out.println("history.back();");
			out.println("</script>");
		} else {
			Boolean newUser = true;
			Cookie[] cookies = request.getCookies();
			for(int i=0; cookies!=null && i < cookies.length; i++ )
			{
				if(cookies[i].getName().equals("lastTitle")) {
					cookies[i].setValue(title);
					response.addCookie(cookies[i]);
					newUser =false;
				}
				if(cookies[i].getName().equals("lastPrice")) {
					cookies[i].setValue(price);
					response.addCookie(cookies[i]);
					newUser =false;
				}
				if(cookies[i].getName().equals("lastDesc")) {
					cookies[i].setValue(desc);
					response.addCookie(cookies[i]);
					newUser =false;
				}
			}
			if(newUser) {
				Cookie lastTitle = new Cookie("lastTitle", "");
				Cookie lastPrice = new Cookie("lastPrice", "");
				Cookie lastDesc = new Cookie("lastDesc", "");
				response.addCookie(lastTitle);
				response.addCookie(lastPrice);
				response.addCookie(lastDesc);
			}
			HttpSession session = request.getSession();
			User temp = (User)session.getAttribute("userinfo");
			if(temp != null) {
				path = "/login/success.jsp";
			}else {
				path = "index.jsp";
			}
			request.getRequestDispatcher(path).forward(request, response);
			
		}

	}

	private void logout(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String root = request.getContextPath();
		String path = "/index.jsp";
		HttpSession session = request.getSession();
		session.invalidate();
		response.sendRedirect(root + path);

	}

	private void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/index.jsp";
		String userid = request.getParameter("id");
		String userpwd = request.getParameter("password");
		User user = null;
		try {
			user = loginService.login(userid, userpwd);
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (user != null) {
			HttpSession session = request.getSession();
			session.setAttribute("userinfo", user);
			path = "/login/success.jsp";
		} else {
			request.setAttribute("msg", "아이디 또는 패스워드가 다릅니다.");
		}
		request.getRequestDispatcher(path).forward(request, response);

	}
	
	
	
}
