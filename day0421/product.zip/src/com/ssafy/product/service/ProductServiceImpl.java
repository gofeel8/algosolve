package com.ssafy.product.service;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.product.dao.ProductDao;
import com.ssafy.product.dao.ProductDaoImpl;
import com.ssafy.product.dto.Product;

public class ProductServiceImpl implements ProductService {
	private ProductDao dao;
	
	public ProductServiceImpl() {
		dao = new ProductDaoImpl();
	}
	@Override
	public boolean insertProduct(Product product) {
		try {
			dao.insertProduct(product);
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public List<Product> selectAll(String key,String word) {
		key = key == null ? "" : key;
		word = word == null ? "" : word;
		try {
			return dao.selectAll(key,word);
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	@Override
	public Product selectNo(int no) {
		Product temp =null;
		try {
			temp = dao.selectNo(no);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return temp;
	}
	@Override
	public boolean delete(int no) {
		try {
			dao.delete(no);
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	@Override
	public boolean fix(int no,Product product) {
		try {
			dao.fix(no,product);
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}


}
