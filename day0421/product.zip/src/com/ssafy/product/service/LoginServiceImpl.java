package com.ssafy.product.service;

import com.ssafy.product.dao.UserDao;
import com.ssafy.product.dao.UserDaoImpl;
import com.ssafy.product.dto.User;

public class LoginServiceImpl implements LoginService {
	
	UserDao userDao;
	
	
	public LoginServiceImpl() {
		userDao = new UserDaoImpl();
	}

	@Override
	public User login(String userid, String userpwd) throws Exception {
		if (userid == null || userpwd == null)
			throw new Exception();
		return userDao.select(userid, userpwd);
	}

}
