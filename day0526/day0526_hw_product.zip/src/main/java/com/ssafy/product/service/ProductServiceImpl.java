package com.ssafy.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.product.dto.Product;
import com.ssafy.product.repo.ProductDAO;


@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductDAO dao;
	
	@Override
	public List<Product> select(String num) {
		return dao.select(num);
	}

	@Override
	public int update(Product product) {
		return dao.update(product);
		}

	@Override
	public int delete(String num) {
		return dao.delete(num);
	}

	@Override
	public int insert(Product product) {
		return dao.insert(product);
	}

}
