package com.ssafy.product.service;

import java.util.List;

import com.ssafy.product.dto.Product;


public interface ProductService {
	List<Product> select(String num);
	int update(Product product);
	int delete(String num);
	int insert(Product product);

}
