package com.ssafy.product.repo;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.product.dto.Product;

@Repository
public class ProductDAOImpl implements ProductDAO{

	@Autowired
	SqlSession sqlsession;

	@Override
	public List<Product> select(String num) {
		return sqlsession.selectList("product.select", num);
	}

	@Override
	public int insert(Product product) {
		return sqlsession.insert("product.insert",product);
	}

	@Override
	public int update(Product product) {
		System.out.println("update:"+product);
		return sqlsession.update("product.update",product);

	}

	@Override
	public int delete(String num) {
		System.out.println("delete:"+num);
		return sqlsession.delete("product.delete",num);
	}

}
