package com.ssafy.product.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.product.dto.Product;
import com.ssafy.product.service.ProductService;

@RestController
public class ProductController {
	@Autowired
	ProductService service;
	
	@GetMapping("/list")
	public List<Product> index(HttpServletRequest request) {
		System.out.println(service.select(request.getParameter("num")));
		return service.select(request.getParameter("num"));
	}
	
	@PostMapping("/list")
	public int put(@RequestBody Product product) {
		System.out.println("도착:"+product);
		return service.insert(product);
	}
	
	@DeleteMapping("/list")
	public int delete(@RequestBody Product product) {
		return service.delete(product.getNum());
	}
	
	@PostMapping("/list2")
	public int update(@RequestBody Product product) {
		System.out.println(product);
		return service.update(product);
	}
}
