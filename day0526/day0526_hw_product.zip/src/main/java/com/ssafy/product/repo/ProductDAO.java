package com.ssafy.product.repo;

import java.util.List;

import com.ssafy.product.dto.Product;

public interface ProductDAO {
	List<Product> select(String id);
	int insert(Product product);
	int update(Product product);
	int delete(String num);
}
