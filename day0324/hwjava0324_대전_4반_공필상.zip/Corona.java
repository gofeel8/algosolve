package hw;

public class Corona {
	String name;
	int level;
	String spreadSpeed;
	
	public Corona() {
		super();
	}
	public Corona(String name, int level, String spreadSpeed) {
		super();
		this.name = name;
		this.level = level;
		this.spreadSpeed = spreadSpeed;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public String getSpreadSpeed() {
		return spreadSpeed;
	}
	public void setSpreadSpeed(String spreadSpeed) {
		this.spreadSpeed = spreadSpeed;
	}


}
