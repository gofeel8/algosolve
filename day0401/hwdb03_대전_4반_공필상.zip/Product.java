package Product;

public class Product {
    private int pdnum;
    private String pdname;
    private int pdprice;
    
    
	public Product() {
		super();
	}


	public Product(int pdnum, String pdname, int pdprice) {
		super();
		this.pdnum = pdnum;
		this.pdname = pdname;
		this.pdprice = pdprice;
	}


	@Override
	public String toString() {
		return "Product [pdnum=" + pdnum + ", pdname=" + pdname + ", pdprice=" + pdprice + "]";
	}


	public int getPdnum() {
		return pdnum;
	}


	public void setPdnum(int pdnum) {
		this.pdnum = pdnum;
	}


	public String getPdname() {
		return pdname;
	}


	public void setPdname(String pdname) {
		this.pdname = pdname;
	}


	public int getPdprice() {
		return pdprice;
	}


	public void setPdprice(int pdprice) {
		this.pdprice = pdprice;
	}

    
}
