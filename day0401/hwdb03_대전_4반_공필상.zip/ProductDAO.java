package Product;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {
	private Connection conn;
	private final static String URL = "jdbc:mysql://127.0.0.1:3305/scott?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8";
	private final static String DB_ID = "ssafy";
	private final static String DB_PW = "ssafy";
	
	
	private static ProductDAO instance;
	
	private ProductDAO() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(URL,DB_ID,DB_PW);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	public static ProductDAO getInstance() {
		if(instance == null)
			instance = new ProductDAO();
		return instance;
	}
	

	public Connection getConnection() {
		if(conn == null) {
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				conn = DriverManager.getConnection(URL,DB_ID,DB_PW);
			} catch (SQLException | ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return conn;
	}
	
	public void close(Connection connection) {
		try {
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void close(Statement statement) {
		try {
			statement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	public void close(ResultSet resultset) {
		try {
			resultset.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void insertProduct(Product product) {
		String sql =
		"INSERT INTO PRODUCT(pdnum,pdname,pdprice) VALUES(?,?,?)";
		PreparedStatement pstmt = null;
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, product.getPdnum());
			pstmt.setString(2, product.getPdname());
			pstmt.setInt(3, product.getPdprice());
			pstmt.execute();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			if(pstmt!=null) {
				close(pstmt);
			}
		}
		
	}

	public void updateProduct(Product product) {
		String sql =
		"UPDATE PRODUCT SET  pdname = ?, pdprice= ? WHERE pdnum= "+product.getPdnum();
	    PreparedStatement pstmt = null;
	    
	    try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, product.getPdname());
			pstmt.setInt(2, product.getPdprice());
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			if(pstmt!=null) {
				close(pstmt);
			}
		}
	}
	
	public void deleteProduct(String pdnum) {
		String sql = 
		"DELETE FROM PRODUCT WHERE pdnum = "+pdnum;
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			if(pstmt!=null) {
				close(pstmt);
			}
		}
		
	}
	
	public Product findProduct(String pdnum) {
		Product rt = null;
		String sql =
		"SELECT * FROM PRODUCT WHERE pdnum="+pdnum;
		PreparedStatement pstmt = null;
		ResultSet result = null;
		try {
			pstmt = conn.prepareStatement(sql);
			result = pstmt.executeQuery();
			if(result.next()) {
				rt = new Product(result.getInt("pdnum"),result.getString("pdname"),result.getInt("pdprice"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			if(pstmt!=null) {
				close(pstmt);
				close(result);
			}
		}
		
		
		return rt;
	}
	
	public List<Product> listProducts(){
		List<Product> rt = new ArrayList<Product>();
		String sql =
		"SELECT * FROM PRODUCT";
		PreparedStatement pstmt = null;
		ResultSet result = null;
		try {
			pstmt = conn.prepareStatement(sql);
			result = pstmt.executeQuery();
			while(result.next()) {
				rt.add(new Product(result.getInt("pdnum"),result.getString("pdname"),result.getInt("pdprice")));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			if(pstmt!=null) {
				close(pstmt);
				close(result);
			}
		}
		
		
		return rt;
	}
	
	public int count() {
		
		return 0;
	}
	
	

}
