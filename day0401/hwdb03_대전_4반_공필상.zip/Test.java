package Product;

import java.util.List;

public class Test {

	public static void main(String[] args) {
		ProductDAO dao = ProductDAO.getInstance();
		dao.getConnection();
		
		System.out.println("==================무드등 추가=====================");
		Product p1 = new Product(121,"무드등",40000);
		dao.insertProduct(p1);
		List<Product> rt = dao.listProducts();
		for(Product temp : rt) {
			System.out.println(temp);
		}
		
		System.out.println("==================무드등 수정=====================");
		p1 = new Product(121,"무드등v2",42000);
		dao.updateProduct(p1);
		
		System.out.println("==================무드등만 조회=====================");
		System.out.println(dao.findProduct("121"));
		

		System.out.println("==================상품 전체 조회=====================");
		rt = dao.listProducts();
		for(Product temp : rt) {
			System.out.println(temp);
		}

		System.out.println("==================무드등 삭제=====================");
		dao.deleteProduct("121");
		rt = dao.listProducts();
		for(Product temp : rt) {
			System.out.println(temp);
		}
		
	}

}
