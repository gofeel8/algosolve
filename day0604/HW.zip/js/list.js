export default {
    template: `  <div>     <h1 class="text-center">사원 목록</h1>
    <div v-if="list.length>0">

        <input type="text" v-model="keyword"> <button class="btn btn-outline-dark" @click="search">검색</button>

        <table class="table table-bordered table-condensed">
            <colgroup>
                <col :style="{'width' : '20%'}" />
                <col :style="{'width' : '25%'}" />
                <col :style="{'width' : '25%'}" />
                <col :style="{'width' : '20%'}" />
            </colgroup>
            <tr>
                <th>이름</th>
                <th>직책</th>
                <th>부서</th>
                <th>연봉</th>
            </tr>
            <tr v-for="emp of list">
                <td>{{emp.name}}</td>
                <td>{{emp.title}}</td>
                <td>{{emp.dept}}</td>
                <td>{{emp.salary}}</td>
            </tr>
        </table>



    </div>
    <div v-else>
        사원이 없습니다.
    </div>
    <div>
        <p class="text-right"><a class="btn btn-outline-primary" href="read.html">사원 등록하기</a></p>
    </div>    
    </div> 
    `,
    data() {
        return {
            keyword: "",
            list: []
        }
    },
    created() {
        const emps = localStorage.getItem('emps');

        let stored = []

        if (emps) {
            stored = JSON.parse(emps);
        } else {
            localStorage.setItem('emps', JSON.stringify(stored));
        }

        this.list = stored;

    },

    methods: {
        search() {
            const emps = localStorage.getItem('emps');
            let stored = []

            if (emps) {
                stored = JSON.parse(emps);
            } else {
                localStorage.setItem('emps', JSON.stringify(stored));
            }

            if (this.keyword.length != 0) {


                this.list = stored.filter((emp) => {
                    return emp.name == this.keyword;
                })
            } else {
                this.list = stored;
            }

        }
    }

}