/**
 * MyMap 생성자로 사용될 함수를 구현
 */


function MyMap(){
	this.put = function(property,value){
		this[property] = value;
	}
};

MyMap.prototype.size=function(){
	var num =0;
	for(var temp in this){
		if(typeof this[temp] == "string")
			num++;
	}
	return num;
}

MyMap.prototype.get=function(key){
	return this[key];
}

MyMap.prototype.remove=function(key){
	delete this[key];
}

MyMap.prototype.clear=function(){
	for(var temp in this){
		if(typeof this[temp] == "string")
		delete this[temp];
	}
}