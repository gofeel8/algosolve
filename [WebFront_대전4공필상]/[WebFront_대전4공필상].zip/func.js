function burger(){
	var img = document.getElementById('clicked');
	img.src = "./images/burger.jpg"
	var title = document.querySelector('#name');
	title.innerHTML="오늘의 메뉴 : 햄버거";
	var alllist = document.querySelectorAll('footer img');
	for(var i=0; i<alllist.length;i++){
		alllist[i].style = "border : 0px;";
	}
	var selected = document.querySelector('footer img[src="./images/burger.jpg"]');
	selected.style ="border : 2px solid black; opacity : 1;";
}
function cake(){
	var img = document.getElementById('clicked');
	img.src = "./images/cake.jpg"
	var title = document.querySelector('#name');
	title.innerHTML="오늘의 메뉴 : 케이크";
	var alllist = document.querySelectorAll('footer img');
	for(var i=0; i<alllist.length;i++){
		alllist[i].style = "border : 0px;";
	}
	var selected = document.querySelector('footer img[src="./images/cake.jpg"]');
	selected.style ="border : 2px solid black; opacity : 1;";
}
function sandwich(){
	var img = document.getElementById('clicked');
	img.src = "./images/sandwich.jpg"
	var title = document.querySelector('#name');
	title.innerHTML="오늘의 메뉴 : 샌드위치";
	var alllist = document.querySelectorAll('footer img');
	for(var i=0; i<alllist.length;i++){
		alllist[i].style = "border : 0px;";
	}
	var selected = document.querySelector('footer img[src="./images/sandwich.jpg"]');
	selected.style ="border : 2px solid black; opacity : 1;";
}
function steak(){
	var img = document.getElementById('clicked');
	img.src = "./images/steak.jpg"
	var title = document.querySelector('#name');
	title.innerHTML="오늘의 메뉴 : 스테이크";
	var alllist = document.querySelectorAll('footer img');
	for(var i=0; i<alllist.length;i++){
		alllist[i].style = "border : 0px;";
	}
	var selected = document.querySelector('footer img[src="./images/steak.jpg"]');
	selected.style ="border : 2px solid black; opacity : 1;";
}


function rand(){
	var num = Math.floor(Math.random()*4);
	switch (num){
	case 0:
		burger();
		break;
	case 1:
		cake();
		break;
	case 2:
		sandwich();
		break;
	case 3:
		steak();
		break;
	}
}